package com.groupfour.testcoveragetool;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestCoverageToolApplicationTests {

	@Test
	void contextLoads() {
	}

}
