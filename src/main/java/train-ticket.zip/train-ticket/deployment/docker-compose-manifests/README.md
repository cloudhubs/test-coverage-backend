> Docker Compose

* You can use `quickstart-docker-compose.yml`to start quickly.

* Also, if you want to track what happened in the system, you can use `docker-compose-with-jaeger.yml`to get it.  We provide a Tracing System based on [Jaeger](https://www.jaegertracing.io). You can visit the Jaeger Webpage at [http://localhost:16686](http://localhost:16686) to view traces in the system.

