

run:
gradle build
gradle init --type java-application
gradle tasks
gradle run
gradle clean assemble


json:
http://www.json.org/
https://github.com/stleary/JSON-java
https://github.com/stleary/JSON-Java-unit-test
api:
https://stleary.github.io/JSON-java/



shiviz:
https://bestchai.bitbucket.io/shiviz/
http://www.cs.ubc.ca/~bestchai/

