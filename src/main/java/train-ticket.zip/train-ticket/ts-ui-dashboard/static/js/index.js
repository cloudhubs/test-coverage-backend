function onLoadBody(){
    setTodayDateRebook();
    setTodayDatePreserve();
    setTodayDateAdvancedSearch();
}